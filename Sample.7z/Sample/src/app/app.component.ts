import { Component, ViewChild } from '@angular/core';
import { SohoMessageService, SohoBusyIndicatorDirective } from 'ids-enterprise-ng';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  @ViewChild(SohoBusyIndicatorDirective, { static: true }) private busyIndicator: SohoBusyIndicatorDirective;

  constructor(private readonly messageService: SohoMessageService) {
    // Set the Locale for the app
    Soho.Locale.set('en-US');
  }

  openBusyIndicator() {
    this.busyIndicator.activated = true;
    setTimeout(() => {
      this.busyIndicator.activated = false;
    }, 5000);
  }

  openMessage() {
    const message = this.messageService.message({
      title: 'Delete Me',
      message: 'Please click on Delete Button',
      buttons: this.getDeleteConfirmationModalButtons(),
    });
    message.open();
  }
  
  private getDeleteConfirmationModalButtons(): SohoModalButton[] {
    return [
      {
        text: 'Click Me!',
        click: (e, modal) => {
          this.openBusyIndicator();
          modal.close();
        },
        isDefault: true
      },
      {
        text: 'Cancel',
        click: (e, modal) => modal.close()
      }
    ];
  }
}
